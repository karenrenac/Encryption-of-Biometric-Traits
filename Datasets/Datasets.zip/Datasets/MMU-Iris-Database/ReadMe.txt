All rights of the MMU iris database are reserved.
users are not permitted to distribute, publish, copy, or disseminate this database.
Please acknowledge MMU Iris Database in your paper and report.
Any inqueries please forward to ccteo@mmu.edu.my.